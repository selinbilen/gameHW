//
//  GameScene.swift
//  CarGame
//
//  Created by selin eylül bilen on 3/31/21.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    override func didMove(to view: SKView) {

    }
    
}
